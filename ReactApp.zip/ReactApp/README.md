The name of the React application is api app.

The technologies I used to develop this applicaion are HTML, CSS, React JS, Bootstrap, Materilaize CSS and APIs

To run this application just go inside the project folder and open the cmd to that path

Run npm install and it will install all the required modules 

In cmd enter command npm start, it will start the application automatically in the browser.

if not just enter the following url in the browser: http://localhost:3000/

After the application will get loaded into the browser and futher information is provided in the Home section of the application.

A video of me running the application is also provided inside the video folder.