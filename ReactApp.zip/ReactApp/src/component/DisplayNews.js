import React from 'react';

const DisplayNews = (props) => {
    return(
        <div className="container mainContent">
            <div className="post card cardStyle" style={{ padding: 10, width: "80%", backgroundColor: "#ADEFD1FF" }}>
                <span className="card-title">{props.title}</span>
                <b>Description: </b><p>{props.description}</p>
                <b>Author: </b><p>{props.author}</p>
                <p><a href={props.readMore}>Read More</a></p>
            </div>
        </div> 
    );
}

export default DisplayNews;