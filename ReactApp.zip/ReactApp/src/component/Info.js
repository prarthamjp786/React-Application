import React from 'react';

const Info = () => {
    return (
        <div className="container infoSection">
            <h3>About this application: </h3>
            <p>This application is designed by me using React JS</p>
            <p>This application has 3 parts</p>
            <ul>
                <li><b>Search Movie:</b></li>
                <li>Click on search movie option, a search box will appear on the screen.</li>
                <li>Enter any movie name of your choice and hit enter</li>
                <li>A list of movies will pop on your screen, click on any one of the movie, it will show the details of the movie.</li>
                <li>Then click on Go Back it take you to the results page.</li>
                <li>I have made use of NYC times movie article API to display this informations.</li>
            </ul>

            <ul>
                <li><b>Google News: </b></li>
                <li>Select Google news, this section will show you the top 10 from all around the world.</li>
                <li>The page shows the news headline, author, description and a read more link that will take you to full description of the article.</li>
                <li>The page refreshes every 5 seconds.</li>
                <li>I have made use of Google News API to fetch the data of news and rendered on the web page using materialize css.</li>
            </ul>

            <ul>
                <li><b>Get Weather:</b></li>
                <li>In this section, enter any city of your choice and hit enter.</li>
                <li>This will give you the current weather condition in that particular city.</li>
                <li>Information includes name of the city, country name, average temperature, minimum and maximum temperature in degree celsius</li>
                <li>It also shows a cloud icon that changes depending on the weather.</li>
                <li>I have made use of awesome weather api to get the details of weather.</li>
            </ul>
        </div>
    );
}

export default Info;