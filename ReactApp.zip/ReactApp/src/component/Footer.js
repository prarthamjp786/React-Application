import React from 'react';

const Footer = () => {
    return (
        <footer className="page-footer blue mainFooter">
          <div className="footer-copyright">
            <div className="container center">
                © 2014 Copyright Text | All rights reserved.
            </div>
          </div>
        </footer>
    );
}

export default Footer;