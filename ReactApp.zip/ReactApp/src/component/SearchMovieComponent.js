import React, { Component } from 'react';
import SearchMovie from './SearchMovie';
import SearchBox from './SearchBox';
import MovieInfo from './MovieInfo';

const MOVIE_API_KEY = process.env.REACT_APP_MOVIE_API_KEY;

class SearchMovieComponent extends Component{
  constructor(){
      super();
      this.state = {
        movies: [],
        searchTerm: undefined,
        currentMovie: null,
        totalResults: undefined
      };
      this.apiKey = process.env.REACT_APP_API;
  }

  viewMovieInfo = (id) => {
    const filteredMovie = this.state.movies.filter(movie => movie.display_title === id );
    const newCurrentMovie = filteredMovie.length > 0 ? filteredMovie[0] : null
    console.log(newCurrentMovie);
    this.setState({
      currentMovie: newCurrentMovie
    });
  }

  closeMovieInfo = () => {
    this.setState({
      currentMovie: null
    });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    fetch(`https://api.nytimes.com/svc/movies/v2/reviews/search.json?query=${this.state.searchTerm}&api-key=${MOVIE_API_KEY}`)
    .then(data => data.json())
    .then(data => {
    console.log(data.num_results);
      this.setState({
        movies: [...data.results],
        totalResults: data.num_results
      }); 
    });
  }

  handleChange = (e) => {
    this.setState({
      searchTerm: e.target.value
    }); 
  }
    
  render(){
    return(
      <div className="container">
        {
          this.state.currentMovie == null ?
          <div>
            <SearchBox handleSubmit={this.handleSubmit} handleChange={this.handleChange} />
            <SearchMovie movies={this.state.movies} viewMovieInfo={this.viewMovieInfo} searchTerm={this.state.searchTerm} />
          </div>
          :<MovieInfo currentMovie={this.state.currentMovie} closeMovieInfo={this.closeMovieInfo} />
        }
      </div>
    );
  }
}

export default SearchMovieComponent; 