import React from 'react';


const Header = () => {
    return (
        <nav className="nav-wrapper blue">
            <div className="container">
                <a href="./Info" className="brand-logo mainHeader">ReactApp</a>
            </div>
        </nav>
    );
}

export default Header;