import React from 'react';

const Navigation = () => {
    return (
        <div className="container">
            <ul className="mainNavigation" > 
                <li className="mainNavigationLinks">
                    <a className="mainNavigationLinks" href="/Info">Home</a>
                </li>
                <li className="mainNavigationLinks">
                    <a className="mainNavigationLinks" href="/SearchMovieComponent">Search Movies</a>
                </li>
                <li className="mainNavigationLinks">
                    <a className="mainNavigationLinks" href="/GoogleNews">Google News</a>
                </li>
                <li className="mainNavigationLinks">
                    <a className="mainNavigationLinks" href="/GetWeatherComponent">Get Weather</a>
                </li>
            </ul>
        </div>
    );
}

export default Navigation;