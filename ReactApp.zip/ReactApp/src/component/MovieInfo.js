import React from 'react';

const MovieInfo = (props) => {
    return (
        <div className="container">
            <div className="row" onClick={props.closeMovieInfo} style={{ cursor:"pointer", paddingTop: 50 }}>
                <i className="fas fa-arrow-left"></i>
                <span style={{marginLeft: 10}}>Go Back</span>
            </div>
            <div className="row">
                <div className="col s12 m4">
                    <img src="https://dtvimages.hs.llnwd.net/e1//db_photos/default/Movies/movies.jpg" 
                    alt="Movie Poster" style={{ height: 660, width: "100%" }} /> 
                </div>
                <div className="col s12 m8">
                    <div className="info-container">
                        <b>Movie Name: </b><p>{props.currentMovie.display_title}</p>
                        <b>Release Date: </b>
                            {
                                props.currentMovie.opening_date == null ? <p>Not Specified</p> : <p>{props.currentMovie.opening_date}</p>
                            }
                        <b>Description: </b><p>{props.currentMovie.summary_short}</p>
                        <b>Author Name: </b><p>{props.currentMovie.byline}</p>
                        <b>Article Headline: </b><p>{props.currentMovie.headline}</p>
                        <b>Read the full article</b><p><a href={props.currentMovie.link.url}>Here</a></p>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default MovieInfo